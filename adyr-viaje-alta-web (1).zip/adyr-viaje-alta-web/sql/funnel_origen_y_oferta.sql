/* ============================================================
   FUNNEL EXPERIAN -> LEADS N -> ALTAS PGD CORRELACIONADAS
   DESDE 2025

   OBJETIVO
   --------
   Obtener por período de Experian:

   1. Solicitudes Experian totales.
   2. Personas solicitantes únicas.
   3. Leads no clientes:
        Party_ID con al menos una evaluación marcada N
        durante el período, contado una sola vez.
   4. Altas PGD correlacionadas con un lead:
        mismo Party_ID y alta PGD en el mismo mes del lead
        o en el mes siguiente.
   5. Apertura de esas altas correlacionadas por oferta:
        EMINENT / PLUS / MOVE / OTROS / SIN DATO.

   REGLA PARA EVITAR DUPLICADOS
   ----------------------------
   Si una alta PGD puede relacionarse con un lead del mes
   corriente y también con uno del mes anterior, se asigna
   al lead más reciente. De esta manera una misma alta PGD
   se cuenta una sola vez.

   IMPORTANTE
   ----------
   - No se usa solicitud_cd ni solicitud_id para correlacionar.
   - La correlación Experian-PGD se realiza por Party_ID.
   - Las altas PGD sin lead N en M0 o M-1 se excluyen.
   - Ejecutar todo en la misma sesión de Teradata.
   ============================================================ */


/* ============================================================
   1. EXPERIAN DESDE 2025
      Una fila por Exp_Experian_ID
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_exp AS
(
    SELECT
        e.Exp_Experian_ID,
        e.Party_ID,

        CAST(e.Exp_Solicitud_Fec_Oper AS DATE)
            AS fecha_solicitud,

        EXTRACT
        (
            YEAR FROM CAST(e.Exp_Solicitud_Fec_Oper AS DATE)
        ) * 100
        +
        EXTRACT
        (
            MONTH FROM CAST(e.Exp_Solicitud_Fec_Oper AS DATE)
        ) AS periodo_solicitud,

        UPPER(TRIM(e.Exp_Cliente_Es_Cliente))
            AS es_cliente,

        e.Exp_Evaluacion_ID,
        e.Exp_Trace_Operacion_ID,
        e.Anio_Proc,
        e.Mes_Proc

    FROM p_dw_explo.exp_experian e

    WHERE
        (
            e.Anio_Proc * 100
            +
            e.Mes_Proc
        ) >= 202501

        AND e.Exp_Experian_ID IS NOT NULL
        AND e.Exp_Solicitud_Fec_Oper IS NOT NULL

    /* Conserva una sola fila por evaluación Experian */
    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY e.Exp_Experian_ID

        ORDER BY
            e.Anio_Proc DESC,
            e.Mes_Proc DESC,
            e.Exp_Evaluacion_ID DESC,
            e.Exp_Trace_Operacion_ID DESC
    ) = 1
)
WITH DATA
PRIMARY INDEX (Party_ID)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (Party_ID)
ON vt_exp
;

COLLECT STATISTICS
    COLUMN (Exp_Experian_ID)
ON vt_exp
;

COLLECT STATISTICS
    COLUMN (periodo_solicitud)
ON vt_exp
;


/* ============================================================
   2. LEADS NO CLIENTES

   Una fila por Party_ID y período entre las evaluaciones N.
   Se conserva el último intento N del mes.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_leads AS
(
    SELECT
        e.Party_ID,
        e.periodo_solicitud,

        e.Exp_Experian_ID
            AS ultimo_exp_experian_id_n,

        e.fecha_solicitud
            AS fecha_ultimo_intento_n,

        COUNT(*) OVER
        (
            PARTITION BY
                e.Party_ID,
                e.periodo_solicitud
        ) AS cantidad_solicitudes_n_mes

    FROM vt_exp e

    WHERE e.Party_ID IS NOT NULL
      AND e.es_cliente = 'N'

    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY
            e.Party_ID,
            e.periodo_solicitud

        ORDER BY
            e.fecha_solicitud DESC,
            e.Exp_Evaluacion_ID DESC,
            e.Exp_Trace_Operacion_ID DESC,
            e.Exp_Experian_ID DESC
    ) = 1
)
WITH DATA
PRIMARY INDEX (Party_ID)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (Party_ID)
ON vt_leads
;

COLLECT STATISTICS
    COLUMN (periodo_solicitud)
ON vt_leads
;


/* ============================================================
   3. UNIVERSO TOTAL DE ALTAS PGD MEJORADO

   Reglas tomadas de la query de PGD:
   - anio >= 2025;
   - party_status_der_cod = 1;
   - segmentos de personas seleccionados;
   - una sola alta por Party_ID.

   No se incorporan los joins con canal ni MAU porque en la
   query compartida no se utilizan para filtrar ni para la
   salida, y pueden multiplicar filas.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_pgd_first AS
(
    SELECT
        x.party_id,
        x.solicitud_id,
        x.periodo_alta_pgd

    FROM
    (
        SELECT
            c.party_id,
            c.solicitud_id,

            c.anio * 100
            +
            c.mes
                AS periodo_alta_pgd,

            ROW_NUMBER() OVER
            (
                PARTITION BY c.party_id

                ORDER BY
                    c.anio,
                    c.mes,
                    c.solicitud_id
            ) AS rn

        FROM p_dw_explo.pgd_clientes_nuevos c

        INNER JOIN
        (
            SELECT DISTINCT
                Seg_Code

            FROM p_lk_explo.segmento_arbol

            WHERE UPPER(TRIM(seg_desc)) IN
            (
                'RENTA ALTA',
                'BANCA PRIVADA',
                'RENTA MEDIA ALTA',
                'RENTA MEDIA MEDIA',
                'RENTA MEDIA BAJA',
                'RENTA BAJA',
                'SIN RENTA',
                'PERSONAS ANSES'
            )
        ) sa
            ON c.Seg_Code = sa.Seg_Code

        WHERE c.anio >= 2025
          AND c.party_id IS NOT NULL
          AND c.party_status_der_cod = 1
    ) x

    WHERE x.rn = 1
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (party_id)
ON vt_pgd_first
;

COLLECT STATISTICS
    COLUMN (periodo_alta_pgd)
ON vt_pgd_first
;


/* ============================================================
   4. ALTAS PGD CORRELACIONADAS CON UN LEAD N

   Condición:
   - mismo Party_ID;
   - alta PGD en el período del lead o en el siguiente.

   Si una alta puede vincularse a dos períodos de lead,
   conserva el período de lead más reciente.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_pgd_con_lead AS
(
    SELECT
        p.party_id,
        p.solicitud_id,
        p.periodo_alta_pgd,

        l.periodo_solicitud
            AS periodo_lead,

        l.ultimo_exp_experian_id_n,
        l.fecha_ultimo_intento_n,
        l.cantidad_solicitudes_n_mes,

        CASE
            WHEN p.periodo_alta_pgd = l.periodo_solicitud
                THEN 'M0'

            WHEN p.periodo_alta_pgd =
                CASE
                    WHEN MOD(l.periodo_solicitud, 100) = 12
                        THEN l.periodo_solicitud + 89
                    ELSE l.periodo_solicitud + 1
                END
                THEN 'M1'

            ELSE 'FUERA_VENTANA'
        END AS momento_conversion

    FROM vt_pgd_first p

    INNER JOIN vt_leads l
        ON p.party_id = l.Party_ID

       AND p.periodo_alta_pgd IN
       (
            l.periodo_solicitud,

            CASE
                WHEN MOD(l.periodo_solicitud, 100) = 12
                    THEN l.periodo_solicitud + 89
                ELSE l.periodo_solicitud + 1
            END
       )

    /* Prioriza el lead más cercano al alta:
       M0 antes que M1. */
    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY p.party_id

        ORDER BY
            l.periodo_solicitud DESC,
            l.fecha_ultimo_intento_n DESC,
            l.ultimo_exp_experian_id_n DESC
    ) = 1
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (party_id)
ON vt_pgd_con_lead
;

COLLECT STATISTICS
    COLUMN (periodo_lead)
ON vt_pgd_con_lead
;

COLLECT STATISTICS
    COLUMN (periodo_alta_pgd)
ON vt_pgd_con_lead
;


/* ============================================================
   5. OFERTA COMERCIAL DE LAS ALTAS PGD CORRELACIONADAS

   Busca FL_SIMPLI:
   - en el mismo período del alta PGD;
   - o en el período siguiente.

   Se prioriza una fila con FL_SIMPLI informado.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_pgd_con_lead_oferta AS
(
    SELECT
        p.party_id,
        p.solicitud_id,
        p.periodo_lead,
        p.periodo_alta_pgd,
        p.momento_conversion,

        a.periodo
            AS periodo_fl_simpli,

        TRIM(a.fl_simpli)
            AS fl_simpli_original,

        CASE
            WHEN a.party_id IS NULL
                THEN 'SIN DATO'

            WHEN a.fl_simpli IS NULL
              OR TRIM(a.fl_simpli) IN ('', '?')
                THEN 'SIN DATO'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'EMINENT BLACK',
                'EMINENT PLATINUM'
            )
                THEN 'EMINENT'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'GALICIA PLUS',
                'GALICIA PLUS GOLD',
                'BLUE',
                'BLUE GOLD',
                'GALICIA BLUE',
                'GALICIA BLUE GOLD'
            )
                THEN 'PLUS'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'MOVE POTENCIAL',
                'MOVE POTENCIAL ANSES',
                'MOVE DIGITAL',
                'TC MOVE',
                'SIN PQ',
                'SIN PAQUETE',
                'TSM'
            )
                THEN 'MOVE'

            ELSE 'OTROS'
        END AS oferta_agrupada

    FROM vt_pgd_con_lead p

    LEFT JOIN ic.ind_arquetipos a
        ON a.party_id = p.party_id

       AND a.periodo IN
       (
            p.periodo_alta_pgd,

            CASE
                WHEN MOD(p.periodo_alta_pgd, 100) = 12
                    THEN p.periodo_alta_pgd + 89
                ELSE p.periodo_alta_pgd + 1
            END
       )

       AND a.periodo >= 202501

    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY p.party_id

        ORDER BY
            CASE
                WHEN a.fl_simpli IS NOT NULL
                 AND TRIM(a.fl_simpli) NOT IN ('', '?')
                    THEN 0
                ELSE 1
            END,

            a.periodo
    ) = 1
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (party_id)
ON vt_pgd_con_lead_oferta
;

COLLECT STATISTICS
    COLUMN (periodo_lead)
ON vt_pgd_con_lead_oferta
;

COLLECT STATISTICS
    COLUMN (oferta_agrupada)
ON vt_pgd_con_lead_oferta
;



/* ============================================================
   6. ORIGEN Y OFERTA DE TODAS LAS ALTAS PGD

   Clasifica cada alta PGD como:
   - VIAJE_EXPERIAN:
       mismo Party_ID con lead N en M0/M1;
   - SIN_VIAJE_EXPERIAN:
       no se encontró lead N en esa ventana.

   SIN_VIAJE_EXPERIAN es una categoría técnica. No debe
   denominarse MANUAL hasta validarla contra canal/origen.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_pgd_origen_oferta AS
(
    SELECT
        p.party_id,
        p.solicitud_id,
        p.periodo_alta_pgd,

        CASE
            WHEN v.party_id IS NOT NULL
                THEN 'VIAJE_EXPERIAN'
            ELSE 'SIN_VIAJE_EXPERIAN'
        END AS origen_alta,

        v.periodo_lead,
        v.momento_conversion,

        a.periodo
            AS periodo_fl_simpli,

        TRIM(a.fl_simpli)
            AS fl_simpli_original,

        CASE
            WHEN a.party_id IS NULL
                THEN 'SIN DATO'

            WHEN a.fl_simpli IS NULL
              OR TRIM(a.fl_simpli) IN ('', '?')
                THEN 'SIN DATO'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'EMINENT BLACK',
                'EMINENT PLATINUM'
            )
                THEN 'EMINENT'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'GALICIA PLUS',
                'GALICIA PLUS GOLD',
                'BLUE',
                'BLUE GOLD',
                'GALICIA BLUE',
                'GALICIA BLUE GOLD'
            )
                THEN 'PLUS'

            WHEN UPPER(TRIM(a.fl_simpli)) IN
            (
                'MOVE POTENCIAL',
                'MOVE POTENCIAL ANSES',
                'MOVE DIGITAL',
                'TC MOVE',
                'SIN PQ',
                'SIN PAQUETE',
                'TSM'
            )
                THEN 'MOVE'

            ELSE 'OTROS'
        END AS oferta_agrupada

    FROM vt_pgd_first p

    LEFT JOIN vt_pgd_con_lead v
        ON p.party_id = v.party_id

    LEFT JOIN ic.ind_arquetipos a
        ON a.party_id = p.party_id

       AND a.periodo IN
       (
            p.periodo_alta_pgd,

            CASE
                WHEN MOD(p.periodo_alta_pgd, 100) = 12
                    THEN p.periodo_alta_pgd + 89
                ELSE p.periodo_alta_pgd + 1
            END
       )

       AND a.periodo >= 202501

    QUALIFY ROW_NUMBER() OVER
    (
        PARTITION BY p.party_id

        ORDER BY
            CASE
                WHEN a.fl_simpli IS NOT NULL
                 AND TRIM(a.fl_simpli) NOT IN ('', '?')
                    THEN 0
                ELSE 1
            END,
            a.periodo
    ) = 1
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS
;

COLLECT STATISTICS
    COLUMN (party_id)
ON vt_pgd_origen_oferta
;

COLLECT STATISTICS
    COLUMN (periodo_alta_pgd)
ON vt_pgd_origen_oferta
;

COLLECT STATISTICS
    COLUMN (origen_alta)
ON vt_pgd_origen_oferta
;

COLLECT STATISTICS
    COLUMN (oferta_agrupada)
ON vt_pgd_origen_oferta
;


/* ============================================================
   7. RESULTADO FINAL EN FORMATO ANCHO
   ============================================================ */

WITH resumen_experian AS
(
    SELECT
        periodo_solicitud,

        COUNT(*)
            AS solicitudes_experian_totales,

        COUNT(DISTINCT Party_ID)
            AS personas_solicitantes_totales

    FROM vt_exp

    GROUP BY 1
),

resumen_leads AS
(
    SELECT
        periodo_solicitud,

        COUNT(*)
            AS leads_no_clientes_experian,

        SUM(cantidad_solicitudes_n_mes)
            AS solicitudes_experian_n

    FROM vt_leads

    GROUP BY 1
),

resumen_pgd AS
(
    SELECT
        periodo_alta_pgd
            AS periodo,

        COUNT(*)
            AS altas_pgd_totales,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                 THEN 1 ELSE 0 END)
            AS altas_pgd_con_viaje_experian,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                 THEN 1 ELSE 0 END)
            AS altas_pgd_sin_viaje_experian,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND momento_conversion = 'M0'
                 THEN 1 ELSE 0 END)
            AS altas_pgd_viaje_m0,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND momento_conversion = 'M1'
                 THEN 1 ELSE 0 END)
            AS altas_pgd_viaje_m1,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'EMINENT'
                 THEN 1 ELSE 0 END)
            AS viaje_eminent,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'PLUS'
                 THEN 1 ELSE 0 END)
            AS viaje_plus,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'MOVE'
                 THEN 1 ELSE 0 END)
            AS viaje_move,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'OTROS'
                 THEN 1 ELSE 0 END)
            AS viaje_otros,

        SUM(CASE WHEN origen_alta = 'VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'SIN DATO'
                 THEN 1 ELSE 0 END)
            AS viaje_sin_dato,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'EMINENT'
                 THEN 1 ELSE 0 END)
            AS sin_viaje_eminent,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'PLUS'
                 THEN 1 ELSE 0 END)
            AS sin_viaje_plus,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'MOVE'
                 THEN 1 ELSE 0 END)
            AS sin_viaje_move,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'OTROS'
                 THEN 1 ELSE 0 END)
            AS sin_viaje_otros,

        SUM(CASE WHEN origen_alta = 'SIN_VIAJE_EXPERIAN'
                  AND oferta_agrupada = 'SIN DATO'
                 THEN 1 ELSE 0 END)
            AS sin_viaje_sin_dato

    FROM vt_pgd_origen_oferta

    GROUP BY 1
),

periodos AS
(
    SELECT periodo_solicitud AS periodo
    FROM resumen_experian

    UNION

    SELECT periodo_solicitud AS periodo
    FROM resumen_leads

    UNION

    SELECT periodo
    FROM resumen_pgd
)

SELECT
    per.periodo,

    COALESCE(e.solicitudes_experian_totales, 0)
        AS solicitudes_experian_totales,

    COALESCE(e.personas_solicitantes_totales, 0)
        AS personas_solicitantes_totales,

    COALESCE(l.leads_no_clientes_experian, 0)
        AS leads_no_clientes_experian,

    COALESCE(l.solicitudes_experian_n, 0)
        AS solicitudes_experian_n,

    COALESCE(p.altas_pgd_totales, 0)
        AS altas_pgd_totales,

    COALESCE(p.altas_pgd_con_viaje_experian, 0)
        AS altas_pgd_con_viaje_experian,

    COALESCE(p.altas_pgd_sin_viaje_experian, 0)
        AS altas_pgd_sin_viaje_experian,

    COALESCE(p.altas_pgd_viaje_m0, 0)
        AS altas_pgd_viaje_m0,

    COALESCE(p.altas_pgd_viaje_m1, 0)
        AS altas_pgd_viaje_m1,

    COALESCE(p.viaje_eminent, 0)
        AS viaje_eminent,

    COALESCE(p.viaje_plus, 0)
        AS viaje_plus,

    COALESCE(p.viaje_move, 0)
        AS viaje_move,

    COALESCE(p.viaje_otros, 0)
        AS viaje_otros,

    COALESCE(p.viaje_sin_dato, 0)
        AS viaje_sin_dato,

    COALESCE(p.sin_viaje_eminent, 0)
        AS sin_viaje_eminent,

    COALESCE(p.sin_viaje_plus, 0)
        AS sin_viaje_plus,

    COALESCE(p.sin_viaje_move, 0)
        AS sin_viaje_move,

    COALESCE(p.sin_viaje_otros, 0)
        AS sin_viaje_otros,

    COALESCE(p.sin_viaje_sin_dato, 0)
        AS sin_viaje_sin_dato,

    CAST(COALESCE(p.altas_pgd_con_viaje_experian, 0)
         AS DECIMAL(18,6))
    /
    NULLIFZERO(COALESCE(p.altas_pgd_totales, 0))
        AS tasa_altas_pgd_con_viaje,

    CAST(COALESCE(p.altas_pgd_sin_viaje_experian, 0)
         AS DECIMAL(18,6))
    /
    NULLIFZERO(COALESCE(p.altas_pgd_totales, 0))
        AS tasa_altas_pgd_sin_viaje

FROM periodos per

LEFT JOIN resumen_experian e
    ON per.periodo = e.periodo_solicitud

LEFT JOIN resumen_leads l
    ON per.periodo = l.periodo_solicitud

LEFT JOIN resumen_pgd p
    ON per.periodo = p.periodo

ORDER BY 1
;


/* ============================================================
   RESULTADO OPCIONAL EN FORMATO LARGO
   Ideal para Power BI o tablas dinámicas de Excel.
   ============================================================ */

/*
SELECT
    periodo_alta_pgd AS periodo,
    origen_alta,
    oferta_agrupada,
    COUNT(*) AS altas

FROM vt_pgd_origen_oferta

GROUP BY 1, 2, 3

ORDER BY 1, 2, 3
;
*/

/* ============================================================
   CONTROLES OPCIONALES
   ============================================================ */

/* 1. Verifica que la apertura comercial cierre contra las
      altas PGD con viaje Experian. */

/*
SELECT
    periodo_alta_pgd,

    COUNT(*)
        AS altas_con_viaje,

    SUM
    (
        CASE
            WHEN oferta_agrupada = 'EMINENT'
                THEN 1
            ELSE 0
        END
    ) AS eminent,

    SUM
    (
        CASE
            WHEN oferta_agrupada = 'PLUS'
                THEN 1
            ELSE 0
        END
    ) AS plus,

    SUM
    (
        CASE
            WHEN oferta_agrupada = 'MOVE'
                THEN 1
            ELSE 0
        END
    ) AS move,

    SUM
    (
        CASE
            WHEN oferta_agrupada = 'OTROS'
                THEN 1
            ELSE 0
        END
    ) AS otros,

    SUM
    (
        CASE
            WHEN oferta_agrupada = 'SIN DATO'
                THEN 1
            ELSE 0
        END
    ) AS sin_dato

FROM vt_pgd_con_lead_oferta

GROUP BY 1

ORDER BY 1
;
*/


/* 2. Control de duplicación en la query original de PGD.
      Si filas_post_joins supera mucho a clientes_unicos,
      los joins están multiplicando las altas. */

/*
SELECT
    c.anio,
    c.mes,

    COUNT(*)
        AS filas_post_joins,

    COUNT(DISTINCT c.party_id)
        AS clientes_unicos,

    COUNT(DISTINCT c.solicitud_id)
        AS solicitudes_unicas

FROM p_dw_explo.pgd_clientes_nuevos c

LEFT JOIN p_dw_explo.solicitud_canal_arbol_unif canal
    ON canal.solicitud_id = c.solicitud_id

INNER JOIN p_lk_explo.segmento_arbol sa
    ON sa.Seg_Code = c.Seg_Code

LEFT JOIN p_dw_explo.mau mau
    ON mau.party_id = c.party_id
   AND
   (
       EXTRACT(YEAR FROM canal.fec_alta) * 100
       +
       EXTRACT(MONTH FROM canal.fec_alta)
   ) + 1 = mau.periodo_nu

WHERE c.anio >= 2025
  AND c.party_status_der_cod = 1
  AND UPPER(TRIM(sa.seg_desc)) IN
  (
      'RENTA ALTA',
      'BANCA PRIVADA',
      'RENTA MEDIA ALTA',
      'RENTA MEDIA MEDIA',
      'RENTA MEDIA BAJA',
      'RENTA BAJA',
      'SIN RENTA',
      'PERSONAS ANSES'
  )

GROUP BY 1, 2

ORDER BY 1, 2
;
*/
