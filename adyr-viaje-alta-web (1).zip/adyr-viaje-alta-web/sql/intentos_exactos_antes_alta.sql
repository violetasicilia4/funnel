/* ============================================================
   INTENTOS EXACTOS ANTES DEL ALTA

   Requiere haber creado previamente:
   - vt_exp: evaluaciones Experian deduplicadas;
   - vt_pgd_con_lead: altas PGD vinculadas por Party_ID a un lead N.

   Objetivo:
   contar las evaluaciones N ocurridas hasta la fecha de alta.

   IMPORTANTE:
   para precisión diaria, completar fecha_alta_pgd con
   solicitud_canal_arbol_unif.fec_alta resumida a una fila por
   solicitud_id. Si no existe fecha, usar solo períodos M0/M1
   como aproximación.
   ============================================================ */

CREATE MULTISET VOLATILE TABLE vt_fecha_alta_pgd AS
(
    SELECT
        p.party_id,
        p.solicitud_id,
        p.periodo_alta_pgd,
        MIN(CAST(c.fec_alta AS DATE)) AS fecha_alta_pgd

    FROM vt_pgd_con_lead p

    LEFT JOIN p_dw_explo.solicitud_canal_arbol_unif c
        ON p.solicitud_id = c.solicitud_id

    GROUP BY 1,2,3
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS;

CREATE MULTISET VOLATILE TABLE vt_intentos_antes_alta AS
(
    SELECT
        a.party_id,
        a.periodo_alta_pgd,
        a.fecha_alta_pgd,

        COUNT(DISTINCT e.Exp_Experian_ID) AS intentos_n_antes_alta,
        MIN(e.fecha_solicitud) AS fecha_primer_intento_n,
        MAX(e.fecha_solicitud) AS fecha_ultimo_intento_n,
        a.fecha_alta_pgd - MIN(e.fecha_solicitud) AS dias_primer_intento_a_alta,
        a.fecha_alta_pgd - MAX(e.fecha_solicitud) AS dias_ultimo_intento_a_alta

    FROM vt_fecha_alta_pgd a

    INNER JOIN vt_exp e
        ON a.party_id = e.Party_ID
       AND e.es_cliente = 'N'
       AND e.fecha_solicitud <= a.fecha_alta_pgd

    GROUP BY 1,2,3
)
WITH DATA
PRIMARY INDEX (party_id)
ON COMMIT PRESERVE ROWS;

SELECT
    periodo_alta_pgd AS periodo,
    COUNT(*) AS altas_experian,
    AVG(CAST(intentos_n_antes_alta AS DECIMAL(18,4))) AS intentos_promedio,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY intentos_n_antes_alta) AS mediana_intentos,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY intentos_n_antes_alta) AS p75_intentos,
    PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY intentos_n_antes_alta) AS p90_intentos,
    SUM(CASE WHEN intentos_n_antes_alta = 1 THEN 1 ELSE 0 END) AS altas_1_intento,
    SUM(CASE WHEN intentos_n_antes_alta = 2 THEN 1 ELSE 0 END) AS altas_2_intentos,
    SUM(CASE WHEN intentos_n_antes_alta = 3 THEN 1 ELSE 0 END) AS altas_3_intentos,
    SUM(CASE WHEN intentos_n_antes_alta >= 4 THEN 1 ELSE 0 END) AS altas_4_o_mas,
    AVG(CAST(dias_primer_intento_a_alta AS DECIMAL(18,4))) AS dias_promedio_desde_primer_intento
FROM vt_intentos_antes_alta
GROUP BY 1
ORDER BY 1;
